data_input1 = [0]
data_input2 = [1]
add1 = []
add2 = []

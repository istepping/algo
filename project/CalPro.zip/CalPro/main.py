import tkinter as tk
from event import *

# 窗口设置
window = tk.Tk()
window.title("计算加权值")
window.geometry("500x400")

# 输入区域
s1 = tk.Scale(window, label="选则概率", from_=0, to=1, orient=tk.HORIZONTAL, length=250, showvalue=1, tickinterval=0.2,
              resolution=0.01, command=input1)
s2 = tk.Scale(window, label="选则权重", from_=0, to=1, orient=tk.HORIZONTAL, length=250, showvalue=1, tickinterval=0.2,
              resolution=0.01, command=input2)
s2.set(1)
t = tk.Text(window, width=36, height=5)
b_add = tk.Button(window, text='添加', font=('Arial', 12), width=10, height=1, command=lambda: add(t=t))

# 输出区域
l_result = tk.Label(window, text='显示结果', bg="white", font=('Arial', 12), width=28, height=2)
b_calc = tk.Button(window, text='计算', font=('Arial', 12), width=10, height=1, command=lambda: calc(lab=l_result))

# 布局设置
s1.place(x=50, y=10, anchor="nw")
s2.place(x=50, y=100, anchor="nw")
b_add.place(x=350, y=90, anchor="nw")
t.place(x=50, y=200, anchor="nw")
b_calc.place(x=350, y=210, anchor="nw")
l_result.place(x=50, y=300, anchor="nw")
# 显示窗口
window.mainloop()

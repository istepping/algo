from data import *
import tkinter as tk
import util


def input1(e):
    data_input1.append(e)
    print(e)


def input2(e):
    data_input2.append(e)
    print(e)


def add(t):
    print(data_input1[-1])
    print(data_input2[-1])
    t.insert('end', data_input1[-1])
    t.insert('end', "," + str(data_input2[-1]) + "   ")
    add1.append(data_input1[-1])
    add2.append(data_input2[-1])


def calc(lab):
    print("计算")
    result = util.calc_weight(add1, add2)
    lab["text"] = str(result)

def calc_weight(input1, input2):
    return sum(list(map(lambda x, y: float(x) * float(y), input1, input2)))
